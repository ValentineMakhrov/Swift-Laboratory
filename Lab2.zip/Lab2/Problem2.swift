import Foundation

//------------------- 1 -------------------//
var chSet : Set = ["a", "b", "c", "d"];
print("1: \(chSet)");

//------------------- 2 -------------------//
var mChSet = chSet;
print("2: \(chSet)");

//------------------- 3 -------------------//
print("2: \(chSet.count)");

//------------------- 4 -------------------//
mChSet.insert("e");
print("4: \(chSet)");

//------------------- 5 -------------------//
var srtChSet = mChSet.sorted();
print("5: \(srtChSet)");

//------------------- 6 -------------------//
print("6: ", terminator:"");
print(mChSet.remove("f"));

//------------------- 7 -------------------//
print("7: ", terminator:"");
var index = mChSet.index(of: "d");
mChSet.remove(at: index!);
for e in mChSet {
    print("\(e) ", terminator:"");
}

//------------------- 8 -------------------//
print();
print("8: ", terminator:"");
print(mChSet.distance(from: mChSet.startIndex, to: mChSet.index(of: "a")!));

//------------------- 9 -------------------//
mChSet.insert("a");
print("\(9): \(mChSet)");

//------------------- 10 -------------------//
print("10: ");
var aSet:Set<AnyHashable> = ["One", "Two", "Three", 1, 2];
var bSet:Set<AnyHashable> = [1, 2, 3, "One", "Two"];
print(aSet);
print(bSet);

//------------------- 11 -------------------//
var cSet = aSet.intersection(bSet);
print("11: \(cSet)");

//------------------- 12 -------------------//
print("12: ");
var aDiff = aSet.subtracting(bSet);
var bDiff = bSet.subtracting(aSet);
print(aDiff);
print(bDiff);

//------------------- 13 -------------------//
var symmetric = aSet.symmetricDifference(bSet);
print("13: \(symmetric)");

//------------------- 14 -------------------//
var union = aSet.union(bSet);
print("14: \(union)");

//------------------- 15 -------------------//
var xSet = Set(2..<4);
var ySet = Set(1..<6);
var zSet:Set = [3,4,2];
var x1Set:Set = [5,6,7];

//------------------- 16 -------------------//
print("16: ", terminator:"");
print(xSet.isSubset(of: ySet));
print(ySet.isSubset(of: xSet));

//------------------- 17 -------------------//
print("17: ", terminator:"");
print(xSet.isSuperset(of: ySet));
print(ySet.isSuperset(of: xSet));

//------------------- 18 -------------------//
print("18: ", terminator:"");
print(xSet == zSet);

//------------------- 19 -------------------//
print("19: ", terminator:"");
print(xSet.isStrictSubset(of: zSet));

//------------------- 20 -------------------//
print("20: ", terminator:"");
print(xSet.isStrictSuperset(of: zSet));

