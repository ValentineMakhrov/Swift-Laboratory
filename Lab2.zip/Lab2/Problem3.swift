import Foundation

//--------------- 1 ---------------//
var nDict = [1:"One", 2:"Two", 3:"Three", 4:"Four", 5:"Five"];
print("1: \(nDict)");

//--------------- 2 ---------------//
print("2: \(nDict[3]!)");

//--------------- 3 ---------------//
var index = nDict.index(nDict.startIndex, offsetBy: 4);
print("3: \(nDict.values[index])");

//--------------- 4 ---------------//
var mNDict:Dictionary = nDict;
print("4: \(mNDict)");

//--------------- 5 ---------------//
mNDict.merge([6:"Seven", 7:"Six"]) {(current, _) in current}
print("5: \(mNDict)");

//--------------- 6 ---------------//
mNDict.updateValue("Six", forKey: 6);
mNDict.updateValue("Seven", forKey: 7);
mNDict.updateValue("Eight", forKey: 8);
print("6: \(mNDict)");

//--------------- 7 ---------------//
mNDict.removeValue(forKey: 5);
print("7: \(mNDict)");

//--------------- 8 ---------------//
index = mNDict.index(mNDict.startIndex, offsetBy: 4);
mNDict.remove(at: index);
print("8: \(mNDict)");

//--------------- 9 ---------------//
print("9: \(mNDict.distance(from: mNDict.index(forKey: 1)!, to: mNDict.index(forKey: 7)!))");

//--------------- 10 ---------------//
var mNDictKeys = mNDict.keys;
print("10: \(mNDictKeys)");

//--------------- 11 ---------------//
var mNDictValues =  mNDict.values;
print("11: \(mNDictValues)");

//--------------- 12 ---------------//
print(mNDict.count);
print(mNDict.keys);
print(mNDict.values);

//--------------- 13 ---------------//
print("13: ");
for (k, v) in mNDict {
    print("\(k): \(v) ", terminator: "");
}
