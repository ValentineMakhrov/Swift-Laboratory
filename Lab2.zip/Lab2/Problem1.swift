import Foundation

//-------------- 1 --------------//
var fibArray = [1,1,2,3,5,8,13,21,34,55];
print(fibArray);

//-------------- 2 --------------//
fibArray.reverse();
print(fibArray);

//-------------- 3 --------------//
var singleArray :[UInt8] = [];
for i in 1...100 {
    if ((i==1 || i==2 || i==3 || i==5 || i==7) || i%2 != 0 && i%3 != 0 && i%5 != 0 && i%7 != 0)
    {
        singleArray.append(UInt8(i));
    }
}
print(singleArray);

//-------------- 4 --------------//
print(singleArray.count);

//-------------- 5 --------------//
print(singleArray[10]);

//-------------- 6 --------------//
print(singleArray[15 ..< 21]);

//-------------- 7 --------------//
var rptArray = Array(repeating: singleArray[10], count: 10);
print(rptArray);

//-------------- 8 --------------//
var AuxArray = [1,3,5,7,9];
var oddArray = Array.init(AuxArray);
print(oddArray);

//-------------- 9 --------------//
oddArray.append(11);
print(oddArray);

//-------------- 10 --------------//
AuxArray = [15, 17, 19];
oddArray += AuxArray;
print(oddArray);

//-------------- 11 --------------//
oddArray.insert(13, at:6);
print(oddArray);

//-------------- 12 --------------//
oddArray.removeSubrange(5..<8);
print(oddArray);

//-------------- 13 --------------//
print(oddArray.removeLast());

//-------------- 14 --------------//
oddArray[1..<oddArray.count-1] = [2,3,4];
print(oddArray);

//-------------- 15 --------------//
oddArray.remove(at: 2);
print(oddArray);

//-------------- 16 --------------//
print(oddArray.contains(3));

//-------------- 17 --------------//
for e in oddArray {
    print("\(e) ", terminator: "");
}
