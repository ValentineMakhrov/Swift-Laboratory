import Foundation

var var12 : UInt8 = 12;
print(var12);

var varN100 : Int8 = -100;
print(varN100);

var var128 : UInt8 = 128;
print(String(format:"%02X", var128));

var min16 : Int16 = Int16.min;
print(min16);

var max64 : UInt64 = UInt64.max;
print(max64);

var var10 : Float = 10;
print(var10);

var var235 : Float = 235.34;
print(var235);

var charA : Character = "a";
print(charA);

var str : String = "Hello world";
print(str);

var varBool : Bool = true;
print(varBool);

var str12 : String = "12";
print(str12);

var strTwelve : String = "twelve";
print(strTwelve);
