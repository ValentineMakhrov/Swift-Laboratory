import Foundation

var integerNumber : Int?;
print(integerNumber);

var decimalNumber : Float?;
print(decimalNumber);

integerNumber = 5;
print(integerNumber!);

integerNumber! += integerNumber!;
print(integerNumber!);

integerNumber! = -integerNumber!;
print(integerNumber!);

decimalNumber = Float(integerNumber!);
print(decimalNumber!);

var pairOrValues = (integerNumber, decimalNumber);

if pairOrValues.0 != nil {
    print(pairOrValues.0!);
}

if pairOrValues.1 != nil {
    print(pairOrValues.1!);
}

if let float = pairOrValues.1 {
    print(float);
}


