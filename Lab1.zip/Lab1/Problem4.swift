import Foundation

//----------- 1 -----------//
var integerNumber : Int?;
print(integerNumber);

//----------- 2 -----------//
var decimalNumber : Float?;
print(decimalNumber);

//----------- 3 -----------//
integerNumber = 5;
print(integerNumber!);

//----------- 4 -----------//
integerNumber! += integerNumber!;
print(integerNumber!);

//----------- 5 -----------//
integerNumber! = -integerNumber!;
print(integerNumber!);

//----------- 6 -----------//
decimalNumber = Float(integerNumber!);
print(decimalNumber!);

//----------- 7 -----------//
var pairOrValues = (integerNumber, decimalNumber);

//----------- 8 -----------//
if pairOrValues.0 != nil {
    print(pairOrValues.0!);
}

//----------- 9 -----------//
if pairOrValues.1 != nil {
    print(pairOrValues.1!);
}

//----------- 10 -----------//
if let float = pairOrValues.1 {
    print(float);
}


