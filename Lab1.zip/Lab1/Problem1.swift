import Foundation

print("Hello World")