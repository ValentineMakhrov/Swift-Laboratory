import Foundation

var str : String = "Hello World. This is Swift programming language";
print(str);

//----------- 1 ------------//
print(str.count);

//----------- 2 ------------//
str = str.replacingOccurrences(of: "i", with: "u");
print(str);

//----------- 3 ------------//
var i4 = str.index(str.startIndex, offsetBy: 4);
var i7 = str.index(str.startIndex, offsetBy: 7-1); // index with alignment
var i10 = str.index(str.startIndex, offsetBy: 10-2); // index with alignment

str.remove(at: i4);
str.remove(at: i7);
str.remove(at: i10);

print(str);

//----------- 4 ------------//
str += " (modified)";
print(str);

//----------- 5 ------------//
print(str.isEmpty);

//----------- 6 ------------//
var chr : Character = ".";
str.append(chr);
print(str);

//----------- 7 ------------//
print(str.starts(with:"Hello"));

//----------- 8 ------------//
print(str.hasSuffix("world."));

//----------- 9 ------------//
str.insert("-", at: str.index(str.startIndex, offsetBy: 10));
print(str);

//----------- 10 ------------//
str = str.replacingOccurrences(of: "Thus us", with: "It is");
print(str);

//----------- 11 ------------//
print(str[str.index(str.startIndex, offsetBy: 3)]);
print(str[str.index(str.startIndex, offsetBy: 14)]);

//----------- 12 ------------//
print(str[str.index(str.startIndex, offsetBy: 9)..<str.index(str.startIndex, offsetBy: 15)]);
